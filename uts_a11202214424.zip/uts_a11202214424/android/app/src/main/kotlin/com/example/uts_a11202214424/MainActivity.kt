package com.example.uts_a11202214424

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
